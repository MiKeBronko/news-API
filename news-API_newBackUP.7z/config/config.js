const secret = 'topsecret';
const mongoDB = 'mongodb://localhost:27017/newsdb';

module.exports = {
  secret,
  mongoDB,
};
